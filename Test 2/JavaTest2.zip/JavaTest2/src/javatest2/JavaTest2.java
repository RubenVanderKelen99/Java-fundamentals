/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javatest2;

/**
 *
 * @author ruben.vanderkelen
 * @version november 2018
 */
import java.util.Scanner;

public class JavaTest2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("Geef je parameter :");
        Scanner scan = new Scanner(System.in);
        String parameter1 = scan.nextLine();

        String eersteKarakter = parameter1.substring(0, 1);
        int lengte = parameter1.length();
        String andereKarakters = parameter1.substring(1, lengte);
        String andereHoofdLetters = andereKarakters.toUpperCase();

        boolean isParameter = (eersteKarakter.equals("?") && andereKarakters.equals(andereHoofdLetters));

        if (isParameter == true) {
            System.out.println("Dit is een correcte parameter.");
        } else {
            System.out.println("Dit is geen correcte parameter.");
        }

        System.out.println("Geef je template tekst :");
        String templateTekst = scan.nextLine();

        boolean bevatParameter = templateTekst.contains(parameter1);

        if (bevatParameter == true) {
            System.out.println(" ");
            System.out.println("De parameter in je template: " + parameter1);
            System.out.println("Geef de waarde voor je parameter: ");
            String input = scan.nextLine();
            System.out.print("" + templateTekst.replace(parameter1, input));
        } else {
            System.out.println("ERROR: template bevat geen parameter.");
        }
    }

}
